#ifndef NODE_TIMER_H
#define NODE_TIMER_H

uint32_t getms();
uint64_t getTime();
void delay(uint32_t ms);

#endif