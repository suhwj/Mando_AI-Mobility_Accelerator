sudo cp sc_mini.rules /etc/udev/rules.d

roslaunch sc_mini start.launch

roslaunch sc_mini rviz.launch
