#include<stdio.h>
#include<math.h>
#include <iostream>

class Serial_io
{
public:
	Serial_io();
	~Serial_io();
	int open_port(const char *port);
	int set_opt(int fd,int nSpeed, int nBits, char nEvent, int nStop);
private:

	//int fd;

};
