#include <stdio.h>
#include <string>
#include <sstream>
#include <vector>
//#include "Serial_io.h"


#define EAI_HEAD_LEN 10
#define EAI_FRAME_LEN_MIN (EAI_HEAD_LEN + 2)
#define EAI_Si_iMAX 100
#define EAI_FRAME_LEN_MAX (EAI_HEAD_LEN + 2*EAI_Si_iMAX)

using namespace std; 

typedef struct{
	float angle_min;        
	float angle_max;        
	float angle_increment;  
	float time_increment;               
	float scan_time;       
	float range_min;        
	float range_max;        
	float ranges[400];
	float angle[400];       
	//float *intensities;   
 
}scan_t;


typedef struct{
	union{
		unsigned char Buffer[EAI_FRAME_LEN_MAX];
		struct{
			unsigned char PHL;
			unsigned char PHH;
			unsigned char CT;
			unsigned char LSN;
			unsigned char FSAL;
			unsigned char FSAH;
			unsigned char LSAL;
			unsigned char LSAH;
			unsigned char CSL;
			unsigned char CSH;
			unsigned char Si[2*EAI_Si_iMAX];
		}Frame;
	};
	int BufferStart;
	int BufferLen;
}EaiDataStr;

namespace sc_m_c
{
	class SCLaser
	{
		public:

			SCLaser();
			~SCLaser();

			void poll(scan_t *scan,int fd);
			void angle_insert(scan_t *scan_in, scan_t *scan_out);
			

		private:

			std::string port_; 
			bool shutting_down_;
	};
}


