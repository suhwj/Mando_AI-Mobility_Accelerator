#include <stdio.h>                                                                                                
#include <stdlib.h> 
#include <math.h>
#include <string.h>
#include <../include/sc_mini_sdk.h>
#include <iostream>    
#include <unistd.h>     
#include <sys/types.h>  
#include <sys/stat.h>   
#include <fcntl.h>      
#include <termios.h>    
#include <errno.h>
#include <vector>
#include <arpa/inet.h>
#include <sstream>

#include "Serial_io.h"

#define ANGLE_MAX_NUMBERS 4000
                                                                
#define ROS_N_MUL 2
#define POINTS_OF_HEAD 3
#define B_HEAD0 0x55
#define B_HEAD1 0xAA
#define B_TAIL 0xFA
#define AngleZoneNumber 15
#define AngleSizePerZone (360.0F/AngleZoneNumber)
#define AngleZoneSampleNo 30
#define COM_FRAME_LEN (2*AngleZoneSampleNo + 9)

using namespace std;

EaiDataStr EaiData = {0};

//雷达盖子的三个柱子所遮住的起止角度（单位：度），请根据实际安装情况设置
const float Notch_angle[6][2]={
	17.11,32.59,
	98.25,116.95,
	147.65,163.02,
	230.08,247.76,
	280.60,297.60,
	326.50,346.38
};
//如果没有雷达盖子，没有屏蔽雷达盖子的需求的话，请将 enable_cover 设置为0，否则为1
const int enable_cover = 1;

const int robot_rotate_compensate_dir = +1;
//雷达安装到机器人底盘时，两者的零点角度偏差（单位：度），请根据实际安装情况设置
float degree_cali= 0.0;
float PI = 3.1415926;
double angle_yaw_new = 0; //note: 最新的陀螺仪角度值
double angle_yaw_old = 0; //note: 上一次的陀螺仪角度值

int Size;
int lidar_start_count;

int AllAngleIndex = 0;


namespace sc_m_c
{
	SCLaser::SCLaser()
	{

	}
	SCLaser::~SCLaser()
	{

	}


	void PutRemainder2Start(unsigned char *btBuffer,int nStart,int nBufLength)
	{
		if (nStart>0)
		{
			for (int i=nStart;i<nStart+nBufLength;i++)
			{   
				btBuffer[i-nStart] = btBuffer[i];
			}   
		}   

	} 

	uint8_t MatchZoneNo = 0;
	int m_nReceivedLength=0; //接收雷达点云数据的接收缓冲区里缓冲的数据长度
	int nSeekStart = 0;
        //unsigned char raw_bytes[ANGLE_MAX_NUMBERS]; //接收雷达点云数据的接收缓冲区
        char raw_bytes[ANGLE_MAX_NUMBERS];
	float Angle_in[ANGLE_MAX_NUMBERS];
	float FilterRatio = 2.5; //滤波功能用到的滤波系数设置为2.5

	/*
	 * 接收雷达点云数据的函数
	 * input/output: scan指针，雷达扫描的点云数据存在scan所指向的数组里
	 * 功能: 1、接收雷达点云数据
	 *       2、对激光雷达结构引起的角度误差进行补偿；
	 *       3、去除雷达盖子的三根柱子所遮住的数据
	 *       4、对激光雷达安装角度进行补偿
	 *       5、对机器人底盘旋转角度进行补偿
	 */
#define RANGES_TIMP_SIZE 500
	void SCLaser::poll(scan_t *scan,int fd)
	{
		int Rcv=0;
		int index, radius;
		bool FrameOK = false;
		char StrBuf[100];
		int CheckFlag=0;//
		bool WaitOneFrame = true;

		char ZoneNo;
		char SampleNumber;
		float Angle_fsa, Angle_lsa;
		short StartAngle;
		short StopAngle;
		float fStartAngle;
		float fIncAngle;
		float fStopAngle;
		float fTempAngle;
		float angle_check;
		float angle_c0,angle_c1;
                memset(scan->ranges,0,sizeof(scan->ranges));
                memset(scan->angle,0,sizeof(scan->angle)); 
		while(true)
		{
			if(/*WaitOneFrame ||*/ EaiData.BufferLen < EAI_FRAME_LEN_MAX) //数据长度太短，继续收数
			{
				int Rcv = read(fd,raw_bytes,EAI_FRAME_LEN_MAX - EaiData.BufferLen);
				if(Rcv > 0 )
				{

					for(int i=0;i<Rcv;i++)
					{
						EaiData.Buffer[EaiData.BufferLen+i]=(unsigned char)raw_bytes[i];
					}
					EaiData.BufferLen += Rcv;
				}
				WaitOneFrame = false;

			}
			else //解析数据
			{
				int i;
				for(i = 0; i < EaiData.BufferLen/* - EAI_FRAME_LEN_MIN*/; i++)
				{
					if(EaiData.Buffer[i] == 0xAA && EaiData.Buffer[i+1] == 0x55)
					{
						CheckFlag = 0;
						if(i != 0)
						{
							PutRemainder2Start(EaiData.Buffer, i, EaiData.BufferLen - i);
							EaiData.BufferLen = EaiData.BufferLen - i;
							i=0;
							if(EaiData.BufferLen < EAI_FRAME_LEN_MIN)
							{
								WaitOneFrame = true;
								break;
							}
						}
						if(EaiData.Frame.CT == 0x01 && EaiData.Frame.LSN == 0x01 
								&& (EaiData.Frame.FSAL & 0x01)
								&& (EaiData.Frame.LSAL & 0x01)
								&& EaiData.Frame.FSAL == EaiData.Frame.LSAL
								&& EaiData.Frame.FSAH == EaiData.Frame.LSAH
						  )
						{
							if(EaiData.Frame.CSL == EaiData.Frame.PHL^EaiData.Frame.CT^EaiData.Frame.FSAL^EaiData.Frame.LSAL^EaiData.Frame.Si[0]
									&& EaiData.Frame.CSH == EaiData.Frame.PHH^EaiData.Frame.LSN^EaiData.Frame.FSAH^EaiData.Frame.LSAH^EaiData.Frame.Si[1])
							{
								WaitOneFrame = true;
								Size = AllAngleIndex > 0 ? AllAngleIndex : 1;
								EaiData.BufferLen = EaiData.BufferLen - EAI_FRAME_LEN_MIN;
								PutRemainder2Start(EaiData.Buffer, EAI_FRAME_LEN_MIN, EaiData.BufferLen);
								AllAngleIndex = 0;
								scan->angle_increment = (2.0*M_PI/Size);
								scan->angle_min = 0.0;
								scan->angle_max = 2*M_PI;
								scan->range_min = 0.10;
								scan->range_max = 12.0; //note: mini_m1c0测量的最远距离是12m
								return; //ok, receive full frame, exit to draw.
							}
							/*******************check failed******************/
							WaitOneFrame = true;
							EaiData.BufferLen = EaiData.BufferLen - EAI_FRAME_LEN_MIN;
							PutRemainder2Start(EaiData.Buffer, EAI_FRAME_LEN_MIN, EaiData.BufferLen);
							AllAngleIndex = 0;
							break;
							/*************************************************/
						}
						else if(EaiData.Frame.CT == 0x00 
								&& 0 < EaiData.Frame.LSN && EaiData.Frame.LSN < EAI_Si_iMAX
								&& (EaiData.Frame.FSAL & 0x01)
								&& (EaiData.Frame.LSAL & 0x01))
						{
							//ROS_INFO("5555555555555555555555555555555");
							if(2*EaiData.Frame.LSN + EAI_HEAD_LEN > EaiData.BufferLen - i)
							{
								WaitOneFrame = true;
								EaiData.BufferLen = EaiData.BufferLen - i;
								break;
							}
							CheckFlag = 1;
							Angle_fsa = (EaiData.Frame.FSAL + EaiData.Frame.FSAH*256)/128.0;
							Angle_lsa = (EaiData.Frame.LSAL + EaiData.Frame.LSAH*256)/128.0;
							//if(Angle_lsa > Angle_fsa)
							{
								unsigned char tempCSL, tempCSH;
								int j;
								tempCSL = EaiData.Frame.PHL^EaiData.Frame.CT^EaiData.Frame.FSAL^EaiData.Frame.LSAL;
								tempCSH = EaiData.Frame.PHH^EaiData.Frame.LSN^EaiData.Frame.FSAH^EaiData.Frame.LSAH;
								for(j=0; j<EaiData.Frame.LSN; j++)
								{
									tempCSL ^= EaiData.Frame.Si[2*j];
									tempCSH ^= EaiData.Frame.Si[2*j+1];
								}
								if(EaiData.Frame.CSL == tempCSL && EaiData.Frame.CSH == tempCSH)
								{ //ok, receive one frame
									CheckFlag = 2;
									fStartAngle = Angle_fsa;
									fStopAngle = Angle_lsa;
									
									if(EaiData.Frame.LSN == 1)
									{
										fIncAngle = 0;
									}
									else
									{
										if(fStartAngle>fStopAngle)
										{
											fIncAngle = (360 - fStartAngle + fStopAngle)/(EaiData.Frame.LSN-1);

										}
										else
										{
											fIncAngle = (fStopAngle - fStartAngle)/(EaiData.Frame.LSN-1);

										}
									}
									//fIncAngle = (fStopAngle - fStartAngle)/(EaiData.Frame.LSN-1);
									for(j=0; j<EaiData.Frame.LSN; j++)
									{
										//radius = (EaiData.Frame.Si[j] + 256*EaiData.Frame.Si[j+1])/16;
										radius = (EaiData.Frame.Si[2*j] | (EaiData.Frame.Si[2*j+1]<<8))/4;
										scan->ranges[AllAngleIndex] = radius/1000.0F;

										if(radius < 10)
										{
											angle_c0 = 0;
										}
										else
										{
											//mini_m1c0
											angle_c0 = (AllAngleIndex == 0) ? 0 : atan( 19.16 * ((float)radius - 90.15) / (90.15*(float)radius) ) * 180 / PI - 12;
									
											//m1c0
											//angle_c0 = (AllAngleIndex == 0) ? 0 : atan( 22.51 * ((float)radius - 170.98) / (170.98*(float)radius) ) * 180 / PI - 7.5;
										}

										fTempAngle = fStartAngle + j * fIncAngle;
										angle_check = 360 - fTempAngle; //note: 形成的点云图反向旋转，让画出来的点云图和实际扫描环境对应上
										angle_c1 = angle_check + angle_c0 ; //note: 进行结构角度补偿
										angle_c1 = angle_c1 > 360 ? (angle_c1-360) : angle_c1;
										angle_c1 = angle_c1 < 0 ? (angle_c1+360) : angle_c1;



										if(enable_cover)
										{
											if(
												(Notch_angle[0][0] < angle_c1 && angle_c1 < Notch_angle[0][1])
												|| (Notch_angle[1][0] < angle_c1 && angle_c1 < Notch_angle[1][1])
												|| (Notch_angle[2][0] < angle_c1 && angle_c1 < Notch_angle[2][1])
												|| (Notch_angle[3][0] < angle_c1 && angle_c1 < Notch_angle[3][1])
												|| (Notch_angle[4][0] < angle_c1 && angle_c1 < Notch_angle[4][1])
												|| (Notch_angle[5][0] < angle_c1 && angle_c1 < Notch_angle[5][1])
											)
											{
												if(scan->ranges[AllAngleIndex] > 0.1)
												{
													scan->ranges[AllAngleIndex]=0;
												}
											}
										}
										angle_c1 += degree_cali;
										//确保angle_c1位于[0, 360)范围内
										if(angle_c1 >= 360)
										{
											int tempint = angle_c1 / 360;
											angle_c1 = angle_c1 - tempint * 360;
										}
										if(angle_c1 < 0)
										{
											int tempint = angle_c1 / 360;
											angle_c1 = angle_c1 - (tempint - 1) * 360;
										}
										
										scan->angle[AllAngleIndex] = /*fTempAngle;*/ 360 - fTempAngle;
										AllAngleIndex++;
                                                                                
                                                                                
									}
									//WaitOneFrame = false;
								}
							}
							if(CheckFlag == 1)
							{

							}

						}
						else //非帧数据
						{
						}
					}
					if(EaiData.BufferLen == (2*EaiData.Frame.LSN + EAI_HEAD_LEN))
					{
						WaitOneFrame = true;
						EaiData.BufferLen = 0;
						break;
					}
				}		
				if(WaitOneFrame == false)//本组数据没有检测到包头
				{
					EaiData.BufferLen = EaiData.BufferLen - i;
					AllAngleIndex = 0;
				}
			}
		}
	}
}

int main(int argc, char **argv)
{
	int fd;
	int baud_rate = 115200;
	std::string frame_id;
	const char *port="/dev/sc_mini";

	Serial_io serial_io;

    	fd = serial_io.open_port(port);
    	serial_io.set_opt(fd,baud_rate,8,'N',1);
         
        scan_t scan;
	scan_t scan_publish;
	
	sc_m_c::SCLaser laser;

	while (1)
	{   
		laser.poll(&scan,fd);
		printf("11111111111111111111111111111111111\n");
		//laser.angle_insert(&scan,&scan_publish); //note:角度插值函数

	}
        close(fd);
	return 0;
	
}
